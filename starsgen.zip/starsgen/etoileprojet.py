from turtle import *
from colorama import *
import random
import os
from pystyle import *
#couleur 
White =  Fore.WHITE
Red = Fore.RED
Racc = f"[+]"

Title = '''
           ▄████████     ███      ▄██████▄   ▄█   ▄█          ▄████████         ▄██████▄     ▄████████ ███▄▄▄▄   
          ███    ███ ▀█████████▄ ███    ███ ███  ███         ███    ███        ███    ███   ███    ███ ███▀▀▀██▄ 
          ███    █▀     ▀███▀▀██ ███    ███ ███▌ ███         ███    █▀         ███    █▀    ███    █▀  ███   ███ 
         ▄███▄▄▄         ███   ▀ ███    ███ ███▌ ███        ▄███▄▄▄           ▄███         ▄███▄▄▄     ███   ███ 
        ▀▀███▀▀▀         ███     ███    ███ ███▌ ███       ▀▀███▀▀▀          ▀▀███ ████▄  ▀▀███▀▀▀     ███   ███ 
          ███    █▄      ███     ███    ███ ███  ███         ███    █▄         ███    ███   ███    █▄  ███   ███ 
          ███    ███     ███     ███    ███ ███  ███▌    ▄   ███    ███        ███    ███   ███    ███ ███   ███ 
          ██████████    ▄████▀    ▀██████▀  █▀   █████▄▄██   ██████████        ████████▀    ██████████  ▀█   █▀
'''

def couleurtitre():
    titreencouleur = Colorate.Horizontal(Colors.blue_to_white, Title)
    print(titreencouleur)

def clearecran():
    os.system('cls')

def Commencer():
    couleurtitre()
    input(Colorate.Horizontal(Colors.blue_to_white,f"\n{Racc} Cliquez sur entrer pour commencer le programme. "))
    clearecran()

def Quitter():
    input(Colorate.Horizontal(Colors.blue_to_white,f"\n{Racc} Cliquez sur entrer pour quitter le programme. "))

def créeétoile(n):
    for i in range(n):
        x = random.randint(-500, 500)
        y = random.randint(-300, 300)
        pu()
        goto(x,y)
        pd()
        hideturtle()
        fd(25), lt(120), fd(25),lt(120), fd(25) #premier triangle
        pu()
        lt(205), fd(13), pd(),rt(85), fd(25),rt(120),fd(25),rt(120),fd(25)#2eme triangle

def demandedétoile():
    try:
        nombredétoile = int(input(Colorate.Horizontal(Colors.blue_to_white,f"\n{Racc} Combien d'étoile tu veux : "))) 
        if nombredétoile < 1:
            print(f"\n{Red} [!] Le nombre d'étoile doit etre de au moin 1") 
        else:
            return nombredétoile
    except ValueError:
        print(f"\n{Red} [!] Veuillez entre un nombre d'étoile valid. ")
        return demandedétoile()    

def menu():
    Commencer()
    couleurtitre()
    couleurfond = str(input(Colorate.Horizontal(Colors.blue_to_white,f"\n{Racc} De quel couleur veut tu ton fond : ")))
    couleurstylo = str(input(Colorate.Horizontal(Colors.blue_to_white,f"\n{Racc} De quel couleur veut tu le stylo : ")))
    epaisseurstylo = int(input(Colorate.Horizontal(Colors.blue_to_white,f"\n{Racc} Quel est l'épaisseur veut tu : ")))
    vitessstylo = int(input(Colorate.Horizontal(Colors.blue_to_white,f"\n{Racc} De quel vitesse veut tu le stylo : ")))
    
    nombredétoile = demandedétoile()
    bgcolor(couleurfond)
    pencolor(couleurstylo)
    pensize(epaisseurstylo)
    speed(vitessstylo)
    créeétoile(nombredétoile)
    Quitter()
    bgcolor

menu()